# coding=utf-8
# project
DATA_PATH = "D:\\workspace\\yolo4a\\data"
PROJECT_PATH = "D:\\workspace\\yolo4a\\"
DETECTION_PATH = "D:\\workspace\\yolo4a\\"
MODEL_TYPE = {
    "TYPE": "Darknet"
}  # YOLO type:YOLOv4, Mobilenet-YOLOv4 or Mobilenetv3-YOLOv4

CONV_TYPE = {"TYPE": "DO_CONV"}  # conv type:DO_CONV or GENERAL
ATTENTION = {"TYPE": "NONE"}  # attention type:SEnet、CBAM or NONE

DARKNET = {
    'CONFIG_PATH': 'config\\MobileNetV2-YOLOv3-Lite-voc.cfg' # 'config\\csmobilenet-v2.cfg' # 'config\\MobileNetV2-YOLOv3-Lite-voc.cfg',
}

# train
TRAIN = {
    "DATA_TYPE": "Customer",  # DATA_TYPE: VOC ,COCO or Customer
    "TRAIN_IMG_SIZE": (288, 384),
    "AUGMENT": True,
    "BATCH_SIZE": 2,
    "MULTI_SCALE_TRAIN": False,
    "IOU_THRESHOLD_LOSS": 0.5,
    "EPOCHS": 300,
    "NUMBER_WORKERS": 2,
    "MOMENTUM": 0.9,
    "WEIGHT_DECAY": 0.0005,
    "LR_INIT": 1e-4,
    "LR_END": 1e-6,
    "WARMUP_EPOCHS": 30,  # or None
}


# val
VAL = {
    "TEST_IMG_SIZE": (288, 384),
    "BATCH_SIZE": 2,
    "NUMBER_WORKERS": 0,
    "CONF_THRESH": 0.005,
    "NMS_THRESH": 0.45,
    "MULTI_SCALE_VAL": True,
    "FLIP_VAL": True,
    "Visual": True,
}

Customer_DATA = {
    "NUM": 1,  # your dataset number
    "CLASSES": ["person"],  # your dataset class
}

VOC_DATA = {
    "NUM": 20,
    "CLASSES": [
        "aeroplane",
        "bicycle",
        "bird",
        "boat",
        "bottle",
        "bus",
        "car",
        "cat",
        "chair",
        "cow",
        "diningtable",
        "dog",
        "horse",
        "motorbike",
        "person",
        "pottedplant",
        "sheep",
        "sofa",
        "train",
        "tvmonitor",
    ],
}

COCO_DATA = {
    "NUM": 80,
    "CLASSES": [
        "person",
        "bicycle",
        "car",
        "motorcycle",
        "airplane",
        "bus",
        "train",
        "truck",
        "boat",
        "traffic light",
        "fire hydrant",
        "stop sign",
        "parking meter",
        "bench",
        "bird",
        "cat",
        "dog",
        "horse",
        "sheep",
        "cow",
        "elephant",
        "bear",
        "zebra",
        "giraffe",
        "backpack",
        "umbrella",
        "handbag",
        "tie",
        "suitcase",
        "frisbee",
        "skis",
        "snowboard",
        "sports ball",
        "kite",
        "baseball bat",
        "baseball glove",
        "skateboard",
        "surfboard",
        "tennis racket",
        "bottle",
        "wine glass",
        "cup",
        "fork",
        "knife",
        "spoon",
        "bowl",
        "banana",
        "apple",
        "sandwich",
        "orange",
        "broccoli",
        "carrot",
        "hot dog",
        "pizza",
        "donut",
        "cake",
        "chair",
        "couch",
        "potted plant",
        "bed",
        "dining table",
        "toilet",
        "tv",
        "laptop",
        "mouse",
        "remote",
        "keyboard",
        "cell phone",
        "microwave",
        "oven",
        "toaster",
        "sink",
        "refrigerator",
        "book",
        "clock",
        "vase",
        "scissors",
        "teddy bear",
        "hair drier",
        "toothbrush",
    ],
}


# model
MODEL = {
    "ANCHORS": [
        [(189/32, 126/32), (137/32,236/32), (265/32,259/32), (390/32, 429/32)],
        [(26/16,  48/16 ), (67/16, 84/16 ), (72/16,175/16 ), (119/16, 218/16)], 
        [(189/32, 126/32), (137/32,236/32), (265/32,259/32), (390/32, 429/32)],
    ],  # Anchors for big obj(142,110),(192,243),(459,401)
    "STRIDES": [8, 16, 32],
    "ANCHORS_PER_SCLAE": 4,

    "LiteYolo": True,
    "SPPLayer": False,
    "PANLayer": True, 
}