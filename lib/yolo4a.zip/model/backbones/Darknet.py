from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np

from utils.parse_config import *

def create_modules(module_defs):
    """
    Constructs module list of layer blocks from module configuration in module_defs
    """
    hyperparams = module_defs.pop(0)
    output_filters = [int(hyperparams["channels"])]
    module_list = nn.ModuleList()
    for module_i, module_def in enumerate(module_defs):
        modules = nn.Sequential()

        if module_def["type"] == "convolutional":
            bn = int(module_def["batch_normalize"])
            filters = int(module_def["filters"])
            kernel_size = int(module_def["size"])
            groups = int(module_def['groups']) if ("groups" in module_def) else 1
            pad = (kernel_size - 1) // 2
            modules.add_module(
                f"conv_{module_i}",
                nn.Conv2d(
                    in_channels=output_filters[-1],
                    out_channels=filters,
                    kernel_size=kernel_size,
                    stride=int(module_def["stride"]),
                    groups=groups,
                    padding=pad,
                    bias=not bn,
                ),
            )
            if bn:
                modules.add_module(f"batch_norm_{module_i}", nn.BatchNorm2d(filters, momentum=0.9, eps=1e-5))

            if module_def["activation"] == "leaky":
                modules.add_module(f"leaky_{module_i}", nn.LeakyReLU(0.1))
            elif module_def["activation"] == "relu":
                modules.add_module(f"relu_{module_i}", nn.ReLU())
            elif module_def["activation"] == "swish":
                modules.add_module(f"hardswish_{module_i}", nn.Hardswish())

        elif module_def["type"] == "maxpool":
            kernel_size = int(module_def["size"])
            stride = int(module_def["stride"])
            if kernel_size == 2 and stride == 1:
                modules.add_module(f"_debug_padding_{module_i}", nn.ZeroPad2d((0, 1, 0, 1)))
            maxpool = nn.MaxPool2d(kernel_size=kernel_size, stride=stride, padding=int((kernel_size - 1) // 2))
            modules.add_module(f"maxpool_{module_i}", maxpool)

        elif module_def["type"] == "upsample":
            upsample = Upsample(scale_factor=int(module_def["stride"]), mode="nearest")
            modules.add_module(f"upsample_{module_i}", upsample)

        elif module_def["type"] == "route":
            layers = [int(x) for x in module_def["layers"].split(",")]
            filters = sum([output_filters[1:][i] for i in layers])
            modules.add_module(f"route_{module_i}", Route(layers))

        elif module_def["type"] == "shortcut":
            filters = output_filters[1:][int(module_def["from"])]
            modules.add_module(f"shortcut_{module_i}", Shortcut(int(module_def["from"])))

        elif module_def["type"] == "yolo":
            anchor_idxs = [int(x) for x in module_def["mask"].split(",")]
            # Extract anchors
            anchors = [int(x) for x in module_def["anchors"].split(",")]
            anchors = [(anchors[i], anchors[i + 1]) for i in range(0, len(anchors), 2)]
            anchors = [anchors[i] for i in anchor_idxs]
            num_classes = int(module_def["classes"])
            img_size = int(hyperparams["height"])
            # Define detection layer
            yolo_layer = YOLOLayer(anchors, num_classes, img_size)
            modules.add_module(f"yolo_{module_i}", yolo_layer)

            # print('yolo_' + str(module_i))

        elif module_def["type"] == "backbone":
            layers = [int(x) for x in module_def["layers"].split(",")]
            filters = [output_filters[l+1] for l in layers]
            hyperparams['backbone.layers'] = layers
            hyperparams['backbone.filters'] = filters

            modules.add_module(f"backbone_{module_i}", EmptyLayer())

            for l in layers:
                print('layer = %d, type = %s, filters = %d' % (l, module_defs[l]['type'],  output_filters[l+1]))
        # Register module list and number of output filters
        module_list.append(modules)
        output_filters.append(filters)

    return hyperparams, module_list


class Upsample(nn.Module):
    """ nn.Upsample is deprecated """

    def __init__(self, scale_factor, mode="bilinear"):
        super(Upsample, self).__init__()
        self.upsampler = nn.Upsample(scale_factor=scale_factor, mode=mode)

    def forward(self, x):
        x = self.upsampler(x) # F.interpolate(x, scale_factor=self.scale_factor, mode=self.mode)
        return x


class EmptyLayer(nn.Module):
    """Placeholder for 'route' and 'shortcut' layers"""

    def __init__(self):
        super(EmptyLayer, self).__init__()

class Route(nn.Module):
    """Placeholder for 'route' and 'shortcut' layers"""
    def __init__(self, route=[]):
        super(Route, self).__init__()
        self.route = route

class Shortcut(nn.Module):
    """Placeholder for 'route' and 'shortcut' layers"""
    def __init__(self, shortcut=[]):
        super(Shortcut, self).__init__()
        self.shortcut = shortcut

class YOLOLayer(nn.Module):
    """Detection layer"""

    def __init__(self, anchors, num_classes, img_dim=416):
        super(YOLOLayer, self).__init__()

    def forward(self, x, targets=None, img_dim=None):
        return x


class DarknetBackbone(nn.Module):
    """YOLOv3 object detection model"""

    def __init__(self, config_path):
        super(DarknetBackbone, self).__init__()
        self.module_defs = parse_model_config(config_path)
        self.hyperparams, self.module_list = create_modules(self.module_defs)
        # self.yolo_layers = [layer[0] for layer in self.module_list if hasattr(layer[0], "metrics")]
        self.seen = 0
        self.header_info = np.array([0, 0, 0, self.seen, 0], dtype=np.int32)
        self.yoloweights = []

    def forward(self, x): # , targets=None):
        img_dim = x.shape[2]
        loss = 0
        layer_outputs, yolo_outputs = [], []
        for i, (module_def, module) in enumerate(zip(self.module_defs, self.module_list)):
            if module_def["type"] in ["convolutional", "upsample", "maxpool"]:
                x = module(x)
            elif module_def["type"] == "route":
                x = torch.cat([layer_outputs[int(layer_i)] for layer_i in module_def["layers"].split(",")], 1)
            elif module_def["type"] == "shortcut":
                layer_i = int(module_def["from"])
                x = layer_outputs[-1] + layer_outputs[layer_i]
            layer_outputs.append(x)
        # yolo_outputs = to_cpu(torch.cat(yolo_outputs, 1))
        return [layer_outputs[l] for l in self.hyperparams['backbone.layers']]
        # yolo_outputs # if targets is None else (loss, yolo_outputs)

    def load_darknet_weights(self, weights_path):
        """Parses and loads the weights stored in 'weights_path'"""

        # Open the weights file
        with open(weights_path, "rb") as f:
            header = np.fromfile(f, dtype=np.int32, count=5)  # First five are header values
            self.header_info = header  # Needed to write header when saving weights
            self.seen = header[3]  # number of images seen during training
            weights = np.fromfile(f, dtype=np.float32)  # The rest are weights

        # Establish cutoff for loading backbone weights
        cutoff = None
        if "darknet53.conv.74" in weights_path:
            cutoff = 75

        if "MobileNetV2--Lite.conv.57" in weights_path:
            cutoff = 57
            
        ptr = 0
        for i, (module_def, module) in enumerate(zip(self.module_defs, self.module_list)):
            if i == cutoff:
                break

            if module_def["type"] == "yolo":
                w = conv_w.detach().numpy()
                w = np.transpose(w, (2, 3, 1, 0))
                w = np.squeeze(w)
                w = np.reshape(w, (w.shape[0], 3, w.shape[1]//3))
                x = w[:, :, 0:5:]
                y = w[:, :, 5+14:5+15:]
                
                # print(x.shape)
                # print(y.shape)

                w = np.concatenate((x, y), axis=2)
                w = np.reshape(w, (w.shape[0], 18))
                w = np.transpose(w, (1, 0))

                self.yoloweights.append(w)
                # print(w.shape)

            if module_def["type"] == "convolutional":
                conv_layer = module[0]
                conv = conv_layer
                if module_def["batch_normalize"]:
                    # Load BN bias, weights, running mean and running variance
                    bn_layer = module[1]
                    num_b = bn_layer.bias.numel()  # Number of biases
                    # Bias
                    bn_b = torch.from_numpy(weights[ptr : ptr + num_b]).view_as(bn_layer.bias)
                    bn_layer.bias.data.copy_(bn_b)
                    ptr += num_b
                    # Weight
                    bn_w = torch.from_numpy(weights[ptr : ptr + num_b]).view_as(bn_layer.weight)
                    bn_layer.weight.data.copy_(bn_w)
                    ptr += num_b
                    # Running Mean
                    bn_rm = torch.from_numpy(weights[ptr : ptr + num_b]).view_as(bn_layer.running_mean)
                    bn_layer.running_mean.data.copy_(bn_rm)
                    ptr += num_b
                    # Running Var
                    bn_rv = torch.from_numpy(weights[ptr : ptr + num_b]).view_as(bn_layer.running_var)
                    bn_layer.running_var.data.copy_(bn_rv)
                    ptr += num_b
                else:
                    # Load conv. bias
                    num_b = conv_layer.bias.numel()
                    conv_b = torch.from_numpy(weights[ptr : ptr + num_b]).view_as(conv_layer.bias)
                    conv_layer.bias.data.copy_(conv_b)
                    ptr += num_b

                # if 'preyolo' in module_def:
                # print(conv_layer.weight.detach().numpy().shape)

                # Load conv. weights
                num_w = conv_layer.weight.numel()
                conv_w = torch.from_numpy(weights[ptr : ptr + num_w]).view_as(conv_layer.weight)
                conv_layer.weight.data.copy_(conv_w)
                ptr += num_w

                # if (module_def["batch_normalize"]):
                #     print("Ci = %d, Co = %d, Ki = %d, Si = %d, Gi = %d" % (conv.in_channels, conv.out_channels, conv.kernel_size[0], conv.stride[0], conv.groups))
                #     print("Load %d bn weigths, %d conv weigths" % (num_b * 4, num_w))
                # else:
                #     print("Ci = %d, Co = %d, Ki = %d, Si = %d, Gi = %d" % (conv.in_channels, conv.out_channels, conv.kernel_size[0], conv.stride[0], conv.groups))
                #     print("Load %d bn weigths, %d conv weigths" % (num_b * 1, num_w))

    def save_darknet_weights(self, path, cutoff=-1):
        """
            @:param path    - path of the new weights file
            @:param cutoff  - save layers between 0 and cutoff (cutoff = -1 -> all are saved)
        """
        fp = open(path, "wb")
        self.header_info[3] = self.seen
        self.header_info.tofile(fp)

        # Iterate through layers
        for i, (module_def, module) in enumerate(zip(self.module_defs[:cutoff], self.module_list[:cutoff])):
            if module_def["type"] == "convolutional":
                conv_layer = module[0]
                # If batch norm, load bn first
                if module_def["batch_normalize"]:
                    bn_layer = module[1]
                    bn_layer.bias.data.cpu().numpy().tofile(fp)
                    bn_layer.weight.data.cpu().numpy().tofile(fp)
                    bn_layer.running_mean.data.cpu().numpy().tofile(fp)
                    bn_layer.running_var.data.cpu().numpy().tofile(fp)
                # Load conv bias
                else:
                    conv_layer.bias.data.cpu().numpy().tofile(fp)
                # Load conv weights
                conv_layer.weight.data.cpu().numpy().tofile(fp)

        fp.close()


class Darknet(nn.Module):
    """YOLOv3 object detection model"""

    def __init__(self, config_path, weight_path, out_channels=18, resume=False):
        super(Darknet, self).__init__()

        self.backbone = DarknetBackbone(config_path)
        self.feature_channels = self.backbone.hyperparams['backbone.filters']

        # self.headers = nn.ModuleList()
        # self.headers.append(nn.Conv2d(384, out_channels, 1, 1))
        # self.headers.append(nn.Conv2d(288, out_channels, 1, 1))

        if weight_path and not resume:
            print(' -- load darknet weights --- ')
            self.load_darknet_weights(weight_path)

    def load_darknet_weights(self, weights_path):
        self.backbone.load_darknet_weights(weights_path)

        # for i in range(len(self.backbone.yoloweights)):
        #     print(self.backbone.yoloweights[i].shape)
        #     conv_w = torch.from_numpy(self.backbone.yoloweights[i]).view_as(self.headers[i].weight)
        #     self.headers[i].weight.data.copy_(conv_w)

    def forward(self, x):
        return self.backbone(x)
        # outputs  = []
        # features = self.backbone(x)
        # for i in range(len(features)):
        #     outputs.append(self.headers[i](features[i]))
        # return outputs

    def freeze(self):
        pass

    def unfreeze(self):
        pass

def _BuildDarknet(config_path, weight_path, out_channels, resume):
    model = Darknet(config_path, weight_path=weight_path, out_channels=out_channels, resume=resume)

    return model, model.feature_channels[-3:]